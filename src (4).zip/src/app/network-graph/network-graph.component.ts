import { Component, OnInit } from '@angular/core';
import * as Highcharts from 'highcharts';
import more from 'highcharts/highcharts-more';
more(Highcharts);
import HighchartsNetworkgraph from 'highcharts/modules/networkgraph'; 
HighchartsNetworkgraph(Highcharts);

@Component({
  selector: 'app-network-graph',
  templateUrl: './network-graph.component.html',
  styleUrls: ['./network-graph.component.css']
})
export class NetworkGraphComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}


highchartss = Highcharts;
   chartOptionss = {   
     chart: {
     name:'gtyhu',
    type: 'networkgraph',
    plotBorderWidth: 1,
     height: '100%',
     size: '100%',
  },

  legend: {
    enabled: false
  },
  plotOptions: {
    series: {
      
       networkgraph: {
      layoutAlgorithm: {
      enableSimulation: true
      }
    }
    }
  },
 series: [{
    marker: {
      radius: 40
      
    },
    dataLabels: {
      enabled: true,
      linkFormat: '',
      allowOverlap: false
    },
     nodes: [{
      id: 'Lily Best',
       marker: {
              radius: 30
            },
            
    },
     {
      id: 'ATM',
      color: 'red'
    }, {
      id: 'Auto Insurance',
      color: 'orange'
    },
    {
      id: 'Auto Loan',
      color: 'green'
    },
    {
      id: 'Automotive',
      color: 'blue'
    },
    {
      id: 'Balance Transfers',
      color: 'pink'
    },
    {
      id: 'Auto Insurance',
      color: 'purple'
    },
    {
      id: 'Department Stores',
      color: 'yellow'
    },
 {
      id: 'Entertainment',
      color: 'grey'
    },

 {
      id: 'Gasoline',
      color: 'DarkOliveGreen'
    },


 {
      id: 'Health Insurance',
      color: 'DarkSeaGreen'
    },


 {
      id: 'Home Improvement',
      color: 'DarkSlateGray'
    },

 {
      id: 'Medical Services',
      color: 'IndianRed'
    },
 {
      id: 'Merchandise',
      color: 'Lime'
    },
 {
      id: 'Mortgage',
      color: 'Navy'
    },
 {
      id: 'Rent',
      color: '#98FB98'
    },
 {
      id: 'Restuarants',
      color: 'PaleVioletRed'
    },
 {
      id: 'Services',
      color: 'PowderBlue'
    },
 {
      id: 'Supermarkets',
      color: 'SandyBrown'
    },

 {
      id: 'Technology',
      color: 'Teal'
    },

 {
      id: 'Services',
      color: 'Turquoise'
    },
{
      id: 'Travel',
      color: 'Thistle'
    },
    ],
    data: [
      {from:'Lily Best', to:'ATM',name:'gtyhu'},
      {from:'Lily Best', to:'Auto Insurance'},
      {from:'Lily Best', to:'Auto Loan'},
       {from:'Lily Best', to:'Automotive'},
        {from:'Lily Best', to:'Balance Transfers'},
         {from:'Lily Best', to:'Department Stores'},
         {from:'Lily Best', to:'Entertainment'},
        {from:'Lily Best', to:'Gasoline'},
         {from:'Lily Best', to:'Health Insurance'},
         {from:'Lily Best',to:'Home Improvement'},
         {from:'Lily Best',to:'Medical Services'},
         {from:'Lily Best', to:'Merchandise'},
         {from:'Lily Best', to:'Mortgage'},
         {from:'Lily Best',to: 'Rent'},
        {from:'Lily Best', to:'Restuarants'},      
         {from:'Lily Best', to:'Services'},
         {from:'Lily Best', to:'Supermarkets'},
          {from:'Lily Best',to: 'Technology'},
          {from:'Lily Best',to: 'Travel'},
    ]
  }]
  }
}