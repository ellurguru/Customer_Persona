import { Component, OnInit } from '@angular/core';
import {latLng, MapOptions, tileLayer, Map, Marker, icon} from 'leaflet';

@Component({
  selector: 'app-maps',
  templateUrl: './maps.component.html',
  styleUrls: ['./maps.component.css']
})
export class MapsComponent implements OnInit {

  map: Map;
  mapOptions: MapOptions;
  
 

  constructor() {
  }

  ngOnInit() {
    this.initializeMapOptions();
  }

  onMapReady(map: Map) {
    this.map = map;
    this.addSampleMarker();
  }

  private initializeMapOptions() {
    this.mapOptions = {
      center: [39.8282, -98.5795],
      zoom: 12,
      maxBounds:[[-100,-200],[90,100]],
      layers: [
        tileLayer(
          'http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
          {
            maxZoom: 5,
            attribution: ' '
          })
      ],
    };
  }

  private addSampleMarker() {
    var locations = [
      ["ATM", 36.29914999, -86.86514528],
      ["Medical Services", 36.49635971, -90.61973744],
      ["Rent", 39.79854444, -76.25832913],
      ["Department Stores", 35.74210064, -107.1293599],
      ["Auto Loan", 44.80478993, -81.39383598]
    ];
    for (var i = 0; i < locations.length; i++) {
      const marker = new Marker([Number(locations[i][1]), Number(locations[i][2])])
      .setIcon(
        icon({
          iconSize: [25, 41],
          iconAnchor: [13, 41],
          iconUrl: 'assets/marker-icon.png'
        }));
    marker.addTo(this.map);
    marker.bindPopup("<b>"+locations[i][0]+"<app-pie-sec></app-pie-sec>",{maxWidth: 50000}).openPopup();
    }
  }

}
