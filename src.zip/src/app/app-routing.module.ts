import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DemographicsComponent } from './demographics/demographics.component';
import { HomeComponent } from './home/home.component';
import { PiechartComponent } from './piechart/piechart.component';
import { PersonalComponent } from './personal/personal.component';

const routes: Routes = [
{ path: '', redirectTo: 'home', pathMatch: 'full'},
{ path: 'home', component: HomeComponent},
{ path: 'demo', component: DemographicsComponent},
{ path: 'pie', component: PiechartComponent},
{ path: 'personal', component: PersonalComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
