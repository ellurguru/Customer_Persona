import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-radial-tree',
  templateUrl: './radial-tree.component.html',
  styleUrls: ['./radial-tree.component.css']
})
export class RadialTreeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
