export class MapPoint {
  name: string;
  latitude: number;
  longitude: number;
}
