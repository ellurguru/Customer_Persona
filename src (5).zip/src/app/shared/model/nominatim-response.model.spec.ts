import { NominatimResponse.Model } from './nominatim-response.model';

describe('NominatimResponse.Model', () => {
  it('should create an instance', () => {
    expect(new NominatimResponse.Model()).toBeTruthy();
  });
});
