import { MapPoint.Model } from './map-point.model';

describe('MapPoint.Model', () => {
  it('should create an instance', () => {
    expect(new MapPoint.Model()).toBeTruthy();
  });
});
