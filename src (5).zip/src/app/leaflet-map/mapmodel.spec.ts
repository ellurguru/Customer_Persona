import { Mapmodel } from './mapmodel';

describe('Mapmodel', () => {
  it('should create an instance', () => {
    expect(new Mapmodel()).toBeTruthy();
  });
});
