import { Component, OnInit,Input } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';
import { Subscription }   from 'rxjs/Subscription';
import { PersonaService } from '../persona.service';
import {Demographics} from "./../demo";

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
 public message:any;

constructor(private pservice:PersonaService){
    
  }
  ngOnInit() {
      this.message=this.pservice.readMessage();
      console.log("hey im here!!");
      console.log(this.message);
      
  }

}