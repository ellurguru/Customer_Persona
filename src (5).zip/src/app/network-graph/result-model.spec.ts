import { ResultModel } from './result-model';

describe('ResultModel', () => {
  it('should create an instance', () => {
    expect(new ResultModel()).toBeTruthy();
  });
});
