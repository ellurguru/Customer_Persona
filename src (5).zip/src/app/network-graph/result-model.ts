export class ResultModel {
    NAME: string;
    CATEGORY: string;
    CLIENT_ID : string;
    AMOUNT : number;
}
