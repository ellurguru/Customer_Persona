import { App.Constants } from './app.constants';

describe('App.Constants', () => {
  it('should create an instance', () => {
    expect(new App.Constants()).toBeTruthy();
  });
});
