import { Component, OnInit } from '@angular/core';
import * as Highcharts from "highcharts";
import * as HighchartsNetworkgraph from "highcharts/modules/networkgraph";

@Component({
  selector: 'app-network-graph',
  templateUrl: './network-graph.component.html',
  styleUrls: ['./network-graph.component.css']
})
export class NetworkGraphComponent implements OnInit {

  title = "app";
  chart;
  updateFromInput = false;
  Highcharts = Highcharts;
  chartConstructor = "chart";
  chartCallback;
  chartOptions = {
    chart: {
      type: "networkgraph",
      height: "150%"
    },
    title: {
      //text: "The Indo-European Laungauge Tree"
    },
    subtitle: {
      //text: "A Force-Directed Network Graph in Highcharts"
    },
    plotOptions: {
      networkgraph: {
        keys: ["from", "to"],
        layoutAlgorithm: {
          enableSimulation: true
        }
      }
    },
    series: [
      {
        marker: {
          radius: 40,
        },
        dataLabels: {
          enabled: true
        },
        data: [
          ["Proto Indo-European", "Balto-Slavic"],
          ["Proto Indo-European", "Germanic"],
          ["Proto Indo-European", "Celtic"],
          ["Proto Indo-European", "Italic"],
          ["Proto Indo-European", "Hellenic"],
          ["Proto Indo-European", "Anatolian"],
          ["Proto Indo-European", "Indo-Iranian"],
          ["Proto Indo-European", "Tocharian"]
         
        ]
      }
    ]
  };

  constructor() {
    const self = this;

    this.chartCallback = chart => {
      self.chart = chart;
    };
  }

  ngOnInit(): void {
  }

}
